﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace miniEditor
{
    public partial class aboutDialog : Form
    {
        // 采用定时器的方式实现轮播图
        private int imgIndex = 0;
        private List<Image> imgList = new List<Image>();
        private Timer timer = new Timer();

        public aboutDialog()
        {
            InitializeComponent();
            imgList.Add(Image.FromFile("./gif/cat01.gif"));
            imgList.Add(Image.FromFile("./gif/cat02.gif"));
            imgList.Add(Image.FromFile("./gif/cat03.gif"));
            imgList.Add(Image.FromFile("./gif/cat04.gif"));
            imgList.Add(Image.FromFile("./gif/cat05.gif"));
            imgList.Add(Image.FromFile("./gif/dog01.gif"));

            label1.Text = "当前显示图片" + 1;
            pictureBox1.Image = imgList[imgIndex];

            timer.Interval = 2000;
            timer.Tick += new EventHandler(TimerTick);
            timer.Enabled = true;

        }

        void TimerTick(object sender, EventArgs e)
        {
            imgIndex++;
            if (imgIndex > imgList.Count - 1) imgIndex = 0;
            label1.Text = "当前显示图片" + (imgIndex + 1).ToString();
            pictureBox1.Image = imgList[imgIndex];
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
    }
}
