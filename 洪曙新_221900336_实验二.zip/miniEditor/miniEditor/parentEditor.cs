﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing;

namespace miniEditor
{
    public partial class parentEditor : Form
    {

        public int fileCounter = 0;
        public static searchDialog findBox;
        private string activeFormName;

        public parentEditor()
        {
            InitializeComponent();
            findBox = new searchDialog(this);
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void New_ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            childEditor child = new childEditor(this, ++this.fileCounter);
            child.Show();
            this.handleMsgChange();
        }

        private void Exit_ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        // 水平排列
        private void 平铺ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LayoutMdi(MdiLayout.TileHorizontal);
        }

        private void 层叠ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LayoutMdi(MdiLayout.Cascade);
        }

        private void 关于ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            aboutDialog ab = new aboutDialog();
            ab.Show();
        }

        private void Open_ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();

            ofd.Title = "打开文档";
            ofd.InitialDirectory = @"C:\";
            ofd.Filter = "Rtf文档(*.rtf)|*.rtf";
            ofd.ValidateNames = true;
            ofd.CheckFileExists = true;
            ofd.CheckPathExists = true;
            ofd.Multiselect = false;
            if(ofd.ShowDialog() == DialogResult.OK)
            {
                childEditor ch = new childEditor(this, ++fileCounter);
                string filename = ofd.FileName;
                ch.loadFile(filename);
                ch.Show();
                this.handleMsgChange();
            }
        }

        private void Save_ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            childEditor ch = (childEditor)this.ActiveMdiChild;
            if(ch == null)
            {
                MessageBox.Show("无窗体。");
                return;
            }
            ch.saveFile();
            
        }

        private void SaveAll_ToolStripMenuItem_Click(object sender, EventArgs e)
        {

            if (this.MdiChildren.Length == 0)
            {
                MessageBox.Show("无窗体。");
                return;
            }

            foreach (Form frm in this.MdiChildren)
            {
                childEditor ch = (childEditor)frm;
                ch.saveFile();
            }
        }

        private void close_toolStripMenuItem_Click(object sender, EventArgs e)
        {
            childEditor ch = (childEditor)this.ActiveMdiChild;
            if (ch == null)
            {
                MessageBox.Show("无窗体。");
                return;
            }
            ch.Close();
            fileCounter --;
            this.handleMsgChange();
        }

        private void closeAll_toolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (this.MdiChildren.Length == 0)
            {
                MessageBox.Show("无窗体。");
                return;
            }

            foreach (Form frm in this.MdiChildren)
            {
                childEditor ch = (childEditor)frm;
                ch.Close();
                fileCounter--;
                this.handleMsgChange();
            }
            fileCounter = 0;
        }

        private void Print_ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            childEditor ch = (childEditor)this.ActiveMdiChild;
            if (ch == null)
            {
                MessageBox.Show("无窗体。");
                return;
            }
            ch.print(sender, e);
        }

        private void PageSet_ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            childEditor ch = (childEditor)this.ActiveMdiChild;
            if (ch == null)
            {
                MessageBox.Show("无窗体。");
                return;
            }
            ch.onFilePageSetup(sender, e);
        }

        private void PrintPreview_ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            childEditor ch = (childEditor)this.ActiveMdiChild;
            if (ch == null)
            {
                MessageBox.Show("当前无有效文档。");
                return;
            }
            ch.printPreview(sender, e);
        }

        private void font_ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            childEditor ch = (childEditor)this.ActiveMdiChild;
            if (ch == null)
            {
                MessageBox.Show("当前无有效文档。");
                return;
            }
            ch.handleFontChanged(sender, e);
        }

        private void Color_ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            childEditor ch = (childEditor)this.ActiveMdiChild;
            if (ch == null)
            {
                MessageBox.Show("当前无有效文档。");
                return;
            }
            ch.handleColorChanged(sender, e);
        }

        private void OtherSave_ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            childEditor ch = (childEditor)this.ActiveMdiChild;
            if (ch == null)
            {
                MessageBox.Show("无窗体。");
                return;
            }
            ch.otherSaveFile();
        }

        private void SelectAll_ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            childEditor ch = (childEditor)this.ActiveMdiChild;
            if (ch == null)
            {
                MessageBox.Show("当前无有效文档。");
                return;
            }
            ch.selectAll();
        }

        private void WordWrap_ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            childEditor ch = (childEditor)this.ActiveMdiChild;
            if (ch == null)
            {
                MessageBox.Show("当前无有效文档。");
                return;
            }
            ch.wordWrap();
            this.WordWrap_ToolStripMenuItem.Checked = !this.WordWrap_ToolStripMenuItem.Checked;
        }

        private void InsertTime_ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            childEditor ch = (childEditor)this.ActiveMdiChild;
            if (ch == null)
            {
                MessageBox.Show("当前无有效文档。");
                return;
            }
            ch.addDate();
        }

        private void Search_ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            findBox.Show();
        }

        private void SearchNextOne_ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            findBox.findBtn_Click(sender, e);
        }

        // 底部信息改变处理
        private void handleMsgChange()
        {
            this.panel1.Controls.Clear();
            if(this.fileCounter == 0)
            {
                label1.Text = "共有0个文档";
            }else if(this.fileCounter == 1)
            {
                label1.Text = "共有1个文档";
            }
            else
            {
                childEditor ch =(childEditor)this.ActiveMdiChild;
                this.activeFormName = ch.getName();
                label1.Text = "共有" + this.fileCounter.ToString() + "个文档，当前激活文档：" + this.activeFormName;
            }
            panel1.Controls.Add(label1);
        }
    }
}
