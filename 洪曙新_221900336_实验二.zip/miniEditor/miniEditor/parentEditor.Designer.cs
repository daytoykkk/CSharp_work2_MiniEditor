﻿namespace miniEditor
{
    partial class parentEditor
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(parentEditor));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.文件aFToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.new_ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.Open_ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.Save_ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.OtherSave_ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.SaveAll_ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.close_toolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.closeAll_toolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.PageSet_ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.PrintPreview_ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.Print_ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.Exit_ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.编辑EToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.设置文本ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.font_ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.Color_ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.Search_ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.SearchNextOne_ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.InsertTime_ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.WordWrap_ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.SelectAll_ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.窗口WToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.层叠ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.平铺ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.帮助HToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.关于ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.toolStripButton1 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton2 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton3 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton4 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton5 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton6 = new System.Windows.Forms.ToolStripButton();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.menuStrip1.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.Color.Linen;
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.文件aFToolStripMenuItem,
            this.编辑EToolStripMenuItem,
            this.窗口WToolStripMenuItem,
            this.帮助HToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.MdiWindowListItem = this.窗口WToolStripMenuItem;
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(982, 30);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // 文件aFToolStripMenuItem
            // 
            this.文件aFToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.new_ToolStripMenuItem,
            this.Open_ToolStripMenuItem,
            this.Save_ToolStripMenuItem,
            this.OtherSave_ToolStripMenuItem,
            this.SaveAll_ToolStripMenuItem,
            this.close_toolStripMenuItem,
            this.closeAll_toolStripMenuItem,
            this.toolStripSeparator1,
            this.PageSet_ToolStripMenuItem,
            this.PrintPreview_ToolStripMenuItem,
            this.Print_ToolStripMenuItem,
            this.toolStripSeparator2,
            this.Exit_ToolStripMenuItem});
            this.文件aFToolStripMenuItem.Name = "文件aFToolStripMenuItem";
            this.文件aFToolStripMenuItem.Size = new System.Drawing.Size(71, 26);
            this.文件aFToolStripMenuItem.Text = "文件(&F)";
            // 
            // new_ToolStripMenuItem
            // 
            this.new_ToolStripMenuItem.Name = "new_ToolStripMenuItem";
            this.new_ToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.N)));
            this.new_ToolStripMenuItem.Size = new System.Drawing.Size(180, 26);
            this.new_ToolStripMenuItem.Text = "新建";
            this.new_ToolStripMenuItem.Click += new System.EventHandler(this.New_ToolStripMenuItem_Click);
            // 
            // Open_ToolStripMenuItem
            // 
            this.Open_ToolStripMenuItem.Name = "Open_ToolStripMenuItem";
            this.Open_ToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.O)));
            this.Open_ToolStripMenuItem.Size = new System.Drawing.Size(180, 26);
            this.Open_ToolStripMenuItem.Text = "打开";
            this.Open_ToolStripMenuItem.Click += new System.EventHandler(this.Open_ToolStripMenuItem_Click);
            // 
            // Save_ToolStripMenuItem
            // 
            this.Save_ToolStripMenuItem.Name = "Save_ToolStripMenuItem";
            this.Save_ToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.S)));
            this.Save_ToolStripMenuItem.Size = new System.Drawing.Size(180, 26);
            this.Save_ToolStripMenuItem.Text = "保存";
            this.Save_ToolStripMenuItem.Click += new System.EventHandler(this.Save_ToolStripMenuItem_Click);
            // 
            // OtherSave_ToolStripMenuItem
            // 
            this.OtherSave_ToolStripMenuItem.Name = "OtherSave_ToolStripMenuItem";
            this.OtherSave_ToolStripMenuItem.Size = new System.Drawing.Size(180, 26);
            this.OtherSave_ToolStripMenuItem.Text = "另存为";
            this.OtherSave_ToolStripMenuItem.Click += new System.EventHandler(this.OtherSave_ToolStripMenuItem_Click);
            // 
            // SaveAll_ToolStripMenuItem
            // 
            this.SaveAll_ToolStripMenuItem.Name = "SaveAll_ToolStripMenuItem";
            this.SaveAll_ToolStripMenuItem.Size = new System.Drawing.Size(180, 26);
            this.SaveAll_ToolStripMenuItem.Text = "全部保存";
            this.SaveAll_ToolStripMenuItem.Click += new System.EventHandler(this.SaveAll_ToolStripMenuItem_Click);
            // 
            // close_toolStripMenuItem
            // 
            this.close_toolStripMenuItem.Name = "close_toolStripMenuItem";
            this.close_toolStripMenuItem.Size = new System.Drawing.Size(180, 26);
            this.close_toolStripMenuItem.Text = "关闭";
            this.close_toolStripMenuItem.Click += new System.EventHandler(this.close_toolStripMenuItem_Click);
            // 
            // closeAll_toolStripMenuItem
            // 
            this.closeAll_toolStripMenuItem.Name = "closeAll_toolStripMenuItem";
            this.closeAll_toolStripMenuItem.Size = new System.Drawing.Size(180, 26);
            this.closeAll_toolStripMenuItem.Text = "全部关闭";
            this.closeAll_toolStripMenuItem.Click += new System.EventHandler(this.closeAll_toolStripMenuItem_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(177, 6);
            // 
            // PageSet_ToolStripMenuItem
            // 
            this.PageSet_ToolStripMenuItem.Name = "PageSet_ToolStripMenuItem";
            this.PageSet_ToolStripMenuItem.Size = new System.Drawing.Size(180, 26);
            this.PageSet_ToolStripMenuItem.Text = "页面设置";
            this.PageSet_ToolStripMenuItem.Click += new System.EventHandler(this.PageSet_ToolStripMenuItem_Click);
            // 
            // PrintPreview_ToolStripMenuItem
            // 
            this.PrintPreview_ToolStripMenuItem.Name = "PrintPreview_ToolStripMenuItem";
            this.PrintPreview_ToolStripMenuItem.Size = new System.Drawing.Size(180, 26);
            this.PrintPreview_ToolStripMenuItem.Text = "打印预览";
            this.PrintPreview_ToolStripMenuItem.Click += new System.EventHandler(this.PrintPreview_ToolStripMenuItem_Click);
            // 
            // Print_ToolStripMenuItem
            // 
            this.Print_ToolStripMenuItem.Name = "Print_ToolStripMenuItem";
            this.Print_ToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.P)));
            this.Print_ToolStripMenuItem.Size = new System.Drawing.Size(180, 26);
            this.Print_ToolStripMenuItem.Text = "打印";
            this.Print_ToolStripMenuItem.Click += new System.EventHandler(this.Print_ToolStripMenuItem_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(177, 6);
            // 
            // Exit_ToolStripMenuItem
            // 
            this.Exit_ToolStripMenuItem.Name = "Exit_ToolStripMenuItem";
            this.Exit_ToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Q)));
            this.Exit_ToolStripMenuItem.Size = new System.Drawing.Size(180, 26);
            this.Exit_ToolStripMenuItem.Text = "退出";
            this.Exit_ToolStripMenuItem.Click += new System.EventHandler(this.Exit_ToolStripMenuItem_Click);
            // 
            // 编辑EToolStripMenuItem
            // 
            this.编辑EToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.设置文本ToolStripMenuItem,
            this.Search_ToolStripMenuItem,
            this.SearchNextOne_ToolStripMenuItem,
            this.InsertTime_ToolStripMenuItem,
            this.WordWrap_ToolStripMenuItem,
            this.SelectAll_ToolStripMenuItem});
            this.编辑EToolStripMenuItem.Name = "编辑EToolStripMenuItem";
            this.编辑EToolStripMenuItem.Size = new System.Drawing.Size(71, 26);
            this.编辑EToolStripMenuItem.Text = "编辑(&E)";
            // 
            // 设置文本ToolStripMenuItem
            // 
            this.设置文本ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.font_ToolStripMenuItem,
            this.Color_ToolStripMenuItem});
            this.设置文本ToolStripMenuItem.Name = "设置文本ToolStripMenuItem";
            this.设置文本ToolStripMenuItem.Size = new System.Drawing.Size(193, 26);
            this.设置文本ToolStripMenuItem.Text = "设置文本";
            // 
            // font_ToolStripMenuItem
            // 
            this.font_ToolStripMenuItem.Name = "font_ToolStripMenuItem";
            this.font_ToolStripMenuItem.Size = new System.Drawing.Size(122, 26);
            this.font_ToolStripMenuItem.Text = "字体";
            this.font_ToolStripMenuItem.Click += new System.EventHandler(this.font_ToolStripMenuItem_Click);
            // 
            // Color_ToolStripMenuItem
            // 
            this.Color_ToolStripMenuItem.Name = "Color_ToolStripMenuItem";
            this.Color_ToolStripMenuItem.Size = new System.Drawing.Size(122, 26);
            this.Color_ToolStripMenuItem.Text = "颜色";
            this.Color_ToolStripMenuItem.Click += new System.EventHandler(this.Color_ToolStripMenuItem_Click);
            // 
            // Search_ToolStripMenuItem
            // 
            this.Search_ToolStripMenuItem.Name = "Search_ToolStripMenuItem";
            this.Search_ToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.F)));
            this.Search_ToolStripMenuItem.Size = new System.Drawing.Size(193, 26);
            this.Search_ToolStripMenuItem.Text = "查找";
            this.Search_ToolStripMenuItem.Click += new System.EventHandler(this.Search_ToolStripMenuItem_Click);
            // 
            // SearchNextOne_ToolStripMenuItem
            // 
            this.SearchNextOne_ToolStripMenuItem.Name = "SearchNextOne_ToolStripMenuItem";
            this.SearchNextOne_ToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.F3;
            this.SearchNextOne_ToolStripMenuItem.Size = new System.Drawing.Size(193, 26);
            this.SearchNextOne_ToolStripMenuItem.Text = "查找下一个";
            this.SearchNextOne_ToolStripMenuItem.Click += new System.EventHandler(this.SearchNextOne_ToolStripMenuItem_Click);
            // 
            // InsertTime_ToolStripMenuItem
            // 
            this.InsertTime_ToolStripMenuItem.Name = "InsertTime_ToolStripMenuItem";
            this.InsertTime_ToolStripMenuItem.Size = new System.Drawing.Size(193, 26);
            this.InsertTime_ToolStripMenuItem.Text = "插入日期/时间";
            this.InsertTime_ToolStripMenuItem.Click += new System.EventHandler(this.InsertTime_ToolStripMenuItem_Click);
            // 
            // WordWrap_ToolStripMenuItem
            // 
            this.WordWrap_ToolStripMenuItem.Name = "WordWrap_ToolStripMenuItem";
            this.WordWrap_ToolStripMenuItem.Size = new System.Drawing.Size(193, 26);
            this.WordWrap_ToolStripMenuItem.Text = "自动换行";
            this.WordWrap_ToolStripMenuItem.Click += new System.EventHandler(this.WordWrap_ToolStripMenuItem_Click);
            // 
            // SelectAll_ToolStripMenuItem
            // 
            this.SelectAll_ToolStripMenuItem.Name = "SelectAll_ToolStripMenuItem";
            this.SelectAll_ToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.A)));
            this.SelectAll_ToolStripMenuItem.Size = new System.Drawing.Size(193, 26);
            this.SelectAll_ToolStripMenuItem.Text = "全选";
            this.SelectAll_ToolStripMenuItem.Click += new System.EventHandler(this.SelectAll_ToolStripMenuItem_Click);
            // 
            // 窗口WToolStripMenuItem
            // 
            this.窗口WToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.层叠ToolStripMenuItem,
            this.平铺ToolStripMenuItem});
            this.窗口WToolStripMenuItem.Name = "窗口WToolStripMenuItem";
            this.窗口WToolStripMenuItem.Size = new System.Drawing.Size(78, 26);
            this.窗口WToolStripMenuItem.Text = "窗口(&W)";
            // 
            // 层叠ToolStripMenuItem
            // 
            this.层叠ToolStripMenuItem.Name = "层叠ToolStripMenuItem";
            this.层叠ToolStripMenuItem.Size = new System.Drawing.Size(122, 26);
            this.层叠ToolStripMenuItem.Text = "层叠";
            this.层叠ToolStripMenuItem.Click += new System.EventHandler(this.层叠ToolStripMenuItem_Click);
            // 
            // 平铺ToolStripMenuItem
            // 
            this.平铺ToolStripMenuItem.Name = "平铺ToolStripMenuItem";
            this.平铺ToolStripMenuItem.Size = new System.Drawing.Size(122, 26);
            this.平铺ToolStripMenuItem.Text = "平铺";
            this.平铺ToolStripMenuItem.Click += new System.EventHandler(this.平铺ToolStripMenuItem_Click);
            // 
            // 帮助HToolStripMenuItem
            // 
            this.帮助HToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.关于ToolStripMenuItem});
            this.帮助HToolStripMenuItem.Name = "帮助HToolStripMenuItem";
            this.帮助HToolStripMenuItem.Size = new System.Drawing.Size(75, 26);
            this.帮助HToolStripMenuItem.Text = "帮助(&H)";
            // 
            // 关于ToolStripMenuItem
            // 
            this.关于ToolStripMenuItem.Name = "关于ToolStripMenuItem";
            this.关于ToolStripMenuItem.Size = new System.Drawing.Size(122, 26);
            this.关于ToolStripMenuItem.Text = "关于";
            this.关于ToolStripMenuItem.Click += new System.EventHandler(this.关于ToolStripMenuItem_Click);
            // 
            // toolStrip1
            // 
            this.toolStrip1.BackColor = System.Drawing.Color.SeaShell;
            this.toolStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripButton1,
            this.toolStripButton2,
            this.toolStripButton3,
            this.toolStripButton4,
            this.toolStripButton5,
            this.toolStripButton6});
            this.toolStrip1.Location = new System.Drawing.Point(0, 30);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(982, 31);
            this.toolStrip1.TabIndex = 2;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // toolStripButton1
            // 
            this.toolStripButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton1.Image")));
            this.toolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton1.Name = "toolStripButton1";
            this.toolStripButton1.Size = new System.Drawing.Size(29, 28);
            this.toolStripButton1.Text = "新建";
            this.toolStripButton1.Click += new System.EventHandler(this.New_ToolStripMenuItem_Click);
            // 
            // toolStripButton2
            // 
            this.toolStripButton2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton2.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton2.Image")));
            this.toolStripButton2.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton2.Name = "toolStripButton2";
            this.toolStripButton2.Size = new System.Drawing.Size(29, 28);
            this.toolStripButton2.Text = "打开";
            this.toolStripButton2.Click += new System.EventHandler(this.Open_ToolStripMenuItem_Click);
            // 
            // toolStripButton3
            // 
            this.toolStripButton3.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton3.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton3.Image")));
            this.toolStripButton3.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton3.Name = "toolStripButton3";
            this.toolStripButton3.Size = new System.Drawing.Size(29, 28);
            this.toolStripButton3.Text = "保存";
            this.toolStripButton3.Click += new System.EventHandler(this.Save_ToolStripMenuItem_Click);
            // 
            // toolStripButton4
            // 
            this.toolStripButton4.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton4.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton4.Image")));
            this.toolStripButton4.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton4.Name = "toolStripButton4";
            this.toolStripButton4.Size = new System.Drawing.Size(29, 28);
            this.toolStripButton4.Text = "全部保存";
            this.toolStripButton4.Click += new System.EventHandler(this.SaveAll_ToolStripMenuItem_Click);
            // 
            // toolStripButton5
            // 
            this.toolStripButton5.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton5.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton5.Image")));
            this.toolStripButton5.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton5.Name = "toolStripButton5";
            this.toolStripButton5.Size = new System.Drawing.Size(29, 28);
            this.toolStripButton5.Text = "打印";
            this.toolStripButton5.Click += new System.EventHandler(this.Print_ToolStripMenuItem_Click);
            // 
            // toolStripButton6
            // 
            this.toolStripButton6.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton6.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton6.Image")));
            this.toolStripButton6.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton6.Name = "toolStripButton6";
            this.toolStripButton6.Size = new System.Drawing.Size(29, 28);
            this.toolStripButton6.Text = "关闭";
            this.toolStripButton6.Click += new System.EventHandler(this.close_toolStripMenuItem_Click);
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel1.BackColor = System.Drawing.Color.Linen;
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(2, 717);
            this.panel1.Margin = new System.Windows.Forms.Padding(0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(980, 33);
            this.panel1.TabIndex = 4;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(10, 12);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(90, 15);
            this.label1.TabIndex = 0;
            this.label1.Text = "共有0个文档";
            // 
            // parentEditor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(982, 753);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.menuStrip1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "parentEditor";
            this.Text = "多文本编辑器";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Form1_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem 文件aFToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 编辑EToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 窗口WToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem new_ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem Open_ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem Save_ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem OtherSave_ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem SaveAll_ToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem PageSet_ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem PrintPreview_ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem Print_ToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripMenuItem Exit_ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 设置文本ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem font_ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem Color_ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem Search_ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem SearchNextOne_ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem InsertTime_ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 帮助HToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem WordWrap_ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem SelectAll_ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 层叠ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 平铺ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 关于ToolStripMenuItem;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton toolStripButton1;
        private System.Windows.Forms.ToolStripButton toolStripButton2;
        private System.Windows.Forms.ToolStripButton toolStripButton3;
        private System.Windows.Forms.ToolStripButton toolStripButton4;
        private System.Windows.Forms.ToolStripButton toolStripButton5;
        private System.Windows.Forms.ToolStripButton toolStripButton6;
        private System.Windows.Forms.ToolStripMenuItem close_toolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem closeAll_toolStripMenuItem;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
    }
}

