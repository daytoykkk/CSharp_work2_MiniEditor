﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace miniEditor
{
    public partial class searchDialog : Form
    {
        private string str;
        private bool isCheck = false;
        public parentEditor parent;

        public searchDialog(parentEditor parent)
        {
            InitializeComponent();
            this.parent = parent;
            this.MdiParent = null;
        }

        private void cancelBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        public void findBtn_Click(object sender, EventArgs e)
        {
            if(str == "")
            {
                MessageBox.Show("请输入查找内容。");
                return;
            }
            childEditor ch = (childEditor)parent.ActiveMdiChild;
            if(ch == null)
            {
                MessageBox.Show("无窗体。");
                return;
            }
            ch.searchText(str, this.isCheck);
        }

        private void input_TextChanged(object sender, EventArgs e)
        {
            this.str = input.Text;
        }

        private void checkBox_CheckedChanged(object sender, EventArgs e)
        {
            this.isCheck = checkBox.Checked;
        }
    }
}
