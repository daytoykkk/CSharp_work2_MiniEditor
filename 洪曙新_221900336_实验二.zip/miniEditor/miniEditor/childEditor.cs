﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing;
using System.Drawing.Printing;


namespace miniEditor
{
    public partial class childEditor : Form
    {
        private int index;
        private string name;
        private bool isChanged;     //是否修改过窗口
        private string[] lines;
        private int linesPrinted = 0;
        private static int find_pos = 0;

        public childEditor(parentEditor parent, int index)
        {
            InitializeComponent();
            this.MdiParent = parent;
            this.index = index;
            this.name = "新建文档" + index.ToString();
            this.Text = this.name;
            this.isChanged = false;
        }

        public void loadFile(string filename)
        {
            try
            {
                richTextBox.LoadFile(filename);
                this.name = filename;
                this.Text = filename;
            } catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }
            this.isChanged = false;
        }

        private void richTextBox_TextChanged(object sender, EventArgs e)
        {
            this.isChanged = true;
        }

        public void saveFile()
        {
            try
            {
                string dir = "C:\\Users\\86151\\Desktop\\";
                if (this.isChanged)
                {
                    if (this.name.Contains("\\"))   //打开的文件
                    {
                        richTextBox.SaveFile(this.name);
                    }
                    else      // 新建的文件
                    {
                        richTextBox.SaveFile(dir + this.name + ".rtf");
                    }
                    MessageBox.Show("保存成功！");
                    this.isChanged = false;
                }
            }catch(System.Exception err)
            {
                MessageBox.Show(err.Message);
            }
        }

        public void otherSaveFile()
        {
            SaveFileDialog sfd = new SaveFileDialog();
            sfd.Filter = "Rtf文档(*.rtf)|*.rtf";
            sfd.FilterIndex = 1;
            sfd.RestoreDirectory = true;
            sfd.FileName = this.name;
            if(sfd.ShowDialog() == DialogResult.OK)
            {
                this.name = sfd.FileName.ToString();
                this.isChanged = true;
                this.saveFile();
            }
        }

        private void childEditor_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (this.isChanged == false) return;
            DialogResult result = MessageBox.Show("是否要保存文档？\n" + this.name, "提示", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question);
            if(result == DialogResult.Yes)
            {
                this.saveFile();
               
            }else if (result == DialogResult.No)
            {
                this.isChanged = false;
            }
            else
            {
                e.Cancel = true;
                return;
            }
        }

        // 打印
        private void onBeginPrint(object sender, PrintEventArgs e)
        {
            char[] param = { '\n' };
            if (dlgPrint.PrinterSettings.PrintRange == PrintRange.Selection)
            {
                lines = richTextBox.SelectedText.Split(param);
            }
            else
            {
                lines = richTextBox.Text.Split(param);
            }

            int i = 0;
            foreach(string s in lines)
            {
                lines[i++] = s.TrimEnd('\r');
            }
        }

        private void OnEndPrint(object sender, PrintEventArgs e)
        {
            lines = null;
        }

        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            int x = e.MarginBounds.Left;
            int y = e.MarginBounds.Top;
            while(linesPrinted < lines.Length)
            {
                e.Graphics.DrawString(lines[linesPrinted++], new Font("Arial", 10), Brushes.Black, x, y);
                y += 15;
                if(y >= e.MarginBounds.Bottom)
                {
                    e.HasMorePages = true;
                    return;
                }
            }

            linesPrinted = 0;
            e.HasMorePages = false;
        }

        public void print(object sender, EventArgs e)
        {
            try
            {
                if(richTextBox.SelectedText != "")
                {
                    dlgPrint.AllowSelection = true;
                }
                if(dlgPrint.ShowDialog() == DialogResult.OK)
                {
                    printDocument1.Print();
                }
            }
            catch(Exception err)
            {
                MessageBox.Show(err.Message, "miniEditor", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            
        }

        // 页面设置
        public void onFilePageSetup(object sender, EventArgs e)
        {
            dlgPageSetup.ShowDialog();
        }

        // 打印预览
        public void printPreview(object sender,EventArgs e)
        {
            dlgPrintPreview.ShowDialog();
        }
   
        // 字体设置
        public void handleFontChanged(object sender, EventArgs e)
        {
            if(fontDialog.ShowDialog() == DialogResult.OK)
            {
                richTextBox.SelectionFont = fontDialog.Font;
            }
        }

        // 颜色设置
        public void handleColorChanged(object sender, EventArgs e)
        {
            if(colorDialog.ShowDialog() == DialogResult.OK)
            {
                richTextBox.SelectionColor = colorDialog.Color;
            }
        }

        // 全选
        public void selectAll()
        {
            richTextBox.SelectAll();
        }
        
        // 自动换行
        public void wordWrap()
        {
            richTextBox.WordWrap = !richTextBox.WordWrap;
        }

        // 插入日期和时间
        public void addDate()
        {
            string date = DateTime.Now.ToLocalTime().ToString();
            int pos = this.richTextBox.SelectionStart;
            this.richTextBox.Text = this.richTextBox.Text.Insert(pos, date);
            pos = pos += date.Length;
            richTextBox.SelectionStart = pos;
        }

        public RichTextBox getTextBox()
        {
            return richTextBox;
        }

        // 查找
        public void searchText(string str, bool isCase)
        {
            int len = richTextBox.Text.Length;
            if(len == 0)
            {
                MessageBox.Show("文本内容为空！");
                return;
            }
            if (str.Length == 0)
            {
                MessageBox.Show("请输入查找内容。");
                return;
            }
            if (find_pos > len)
            {
                MessageBox.Show("搜索完毕。");
                find_pos = 0;
                return;
            }
            find_pos = richTextBox.Find(str, find_pos, len, isCase? RichTextBoxFinds.Reverse:RichTextBoxFinds.None);
            if(find_pos == -1)
            {
                MessageBox.Show("搜索完毕。");
                find_pos = 0;
                return;
            }
            else
            {
                richTextBox.Focus();
                richTextBox.Select(find_pos, str.Length);
                find_pos += str.Length;
            }
        }

        // 返回文件名
        public string getName()
        {
            return this.name;
        }

       
    }
}
